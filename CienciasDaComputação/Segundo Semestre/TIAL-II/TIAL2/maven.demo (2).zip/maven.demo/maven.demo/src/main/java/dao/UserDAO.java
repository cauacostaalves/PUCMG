package dao;

import model.Usuario;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDateTime;


public class UserDAO extends DAO {
    public UserDAO() {
        super();
        conectar();
    }

    @Override
    public void finalize() {
        close();
    }

    public boolean insert(Usuario user) throws Exception {        
        if (getByEmail(user.getEmail()) != null) {
            System.out.println("Usuário com este e-mail já existe.");
            return false;
        }

        String sql = "INSERT INTO usuario (email, senha, nome, endereco, data_cadastro) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conexao.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, user.getEmail());
            stmt.setString(2, DAO.toMD5(user.getSenha()));
            stmt.setString(3, user.getNome());
            stmt.setString(4, user.getEndereco()); 
            stmt.setTimestamp(5, Timestamp.valueOf(LocalDateTime.now())); 
            int affectedRows = stmt.executeUpdate();

            if (affectedRows > 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        user.setId(generatedKeys.getInt(1));
                    } else {
                        throw new SQLException("Criando usuário falhou, ID não obtido.");
                    }
                }
            }
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public Usuario getByEmail(String email) {
        try {
            String sql = "SELECT * FROM usuario WHERE email = ?";
            PreparedStatement stmt = conexao.prepareStatement(sql);
            stmt.setString(1, email);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return new Usuario(rs.getInt("id"), rs.getString("email"), rs.getString("senha"), rs.getString("nome"), rs.getString("endereco"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public Usuario getByEmailAndPassword(String email, String senha) throws Exception {
        try {
            String sql = "SELECT * FROM usuario WHERE email = ? AND senha = ?";
            PreparedStatement stmt = conexao.prepareStatement(sql);
            stmt.setString(1, email);
            stmt.setString(2, DAO.toMD5(senha));
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return new Usuario(rs.getInt("id"), rs.getString("email"), rs.getString("senha"), rs.getString("nome"), rs.getString("endereco"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public boolean update(Usuario usuario) throws Exception {
        boolean status = false;
        try {
            String sql = "UPDATE usuario SET email = ?, senha = ?, nome = ?, endereco = ? WHERE id = ?";
            PreparedStatement st = conexao.prepareStatement(sql);
            st.setString(1, usuario.getEmail());
            st.setString(2, DAO.toMD5(usuario.getSenha()));
            st.setString(3, usuario.getNome());
            st.setString(4, usuario.getEndereco());
            st.setInt(5, usuario.getId());
            st.executeUpdate();
            status = true;
        } catch (SQLException u) {
            throw new RuntimeException(u);
        }
        return status;
    }

    public boolean delete(int id) {
        boolean status = false;
        String sql = "DELETE FROM usuario WHERE id = ?";
        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setInt(1, id);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                status = true;
            }
        } catch (SQLException u) {
            throw new RuntimeException(u);
        }
        return status;
    }
}
