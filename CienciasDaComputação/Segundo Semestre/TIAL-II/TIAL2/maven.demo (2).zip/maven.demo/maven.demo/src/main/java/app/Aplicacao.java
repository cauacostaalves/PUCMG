package app;

import static spark.Spark.*;
import service.UsuarioService;
import service.EsporteService;

class Aplicacao {

}
