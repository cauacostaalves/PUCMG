package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

class DAO {
	protected Connection conexao;
	
	public DAO() {
		conexao = null;
	}
	
	public boolean conectar() {
		boolean status = false;
		
		try {
            Connection conexao = DriverManager.getConnection("jdbc:postgresql://localhost:5432/MatchPoint", "postgres", "pdal1313");
            if (conexao != null) {
                System.out.println("Banco de dados conectado com sucesso");
                status = true;
                Statement stm = conexao.createStatement();
            } else {
                System.out.println("Conexao falhou");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
		return status;
	}
}
